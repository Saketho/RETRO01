export const Button = ({ children, className }) => <button className={`bg-blue-600 text-white py-2 rounded ${className}`}>{children}</button>;
